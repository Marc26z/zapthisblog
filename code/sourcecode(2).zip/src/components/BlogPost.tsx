import { formatDistanceToNow } from 'date-fns';
import type { NostrEvent } from '@nostrify/nostrify';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { CalendarIcon, ClockIcon } from 'lucide-react';
import { useAuthor } from '@/hooks/useAuthor';
import { getBlogPostMetadata } from '@/hooks/useBlogPosts';
import { MarkdownRenderer } from '@/components/MarkdownRenderer';
import { CommentsSection } from '@/components/comments/CommentsSection';

interface BlogPostProps {
  event: NostrEvent;
  showComments?: boolean;
}

export function BlogPost({ event, showComments = false }: BlogPostProps) {
  const author = useAuthor(event.pubkey);
  const metadata = getBlogPostMetadata(event);

  const authorMetadata = author.data?.metadata;
  const displayName = authorMetadata?.display_name || authorMetadata?.name || 'Anonymous';
  const profileImage = authorMetadata?.picture;

  const publishedDate = new Date(metadata.publishedAt * 1000);
  const updatedDate = new Date(metadata.createdAt * 1000);
  const isUpdated = metadata.publishedAt !== metadata.createdAt;

  return (
    <article className="space-y-6 sm:space-y-8">
      <Card className="border-0 shadow-lg overflow-hidden">
        {metadata.image && (
          <div className="aspect-video w-full overflow-hidden">
            <img
              src={metadata.image}
              alt={metadata.title}
              className="h-full w-full object-cover"
              loading="lazy"
            />
          </div>
        )}

        <CardHeader className="space-y-4 p-4 sm:p-6">
          <div className="flex items-start space-x-3">
            <Avatar className="h-10 w-10 sm:h-12 sm:w-12 flex-shrink-0">
              <AvatarImage src={profileImage} alt={displayName} />
              <AvatarFallback className="bg-primary text-primary-foreground">
                {displayName.charAt(0).toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0 space-y-1">
              <p className="text-sm sm:text-base font-medium leading-none truncate">{displayName}</p>
              <div className="flex flex-col sm:flex-row sm:items-center sm:space-x-4 space-y-1 sm:space-y-0 text-xs sm:text-sm text-muted-foreground">
                <div className="flex items-center space-x-1">
                  <CalendarIcon className="h-3 w-3 flex-shrink-0" />
                  <span>{publishedDate.toLocaleDateString()}</span>
                </div>
                {isUpdated && (
                  <div className="flex items-center space-x-1">
                    <ClockIcon className="h-3 w-3 flex-shrink-0" />
                    <span className="truncate">Updated {formatDistanceToNow(updatedDate, { addSuffix: true })}</span>
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="space-y-3 sm:space-y-4">
            <h1 className="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-bold leading-tight tracking-tight">
              {metadata.title}
            </h1>

            {metadata.summary && (
              <p className="text-base sm:text-lg text-muted-foreground leading-relaxed">
                {metadata.summary}
              </p>
            )}

            {metadata.topics.length > 0 && (
              <div className="flex flex-wrap gap-1.5 sm:gap-2">
                {metadata.topics.map((topic) => (
                  <Badge key={topic} variant="secondary" className="text-xs">
                    #{topic}
                  </Badge>
                ))}
              </div>
            )}
          </div>
        </CardHeader>

        <CardContent className="p-4 sm:p-6 pt-0">
          <MarkdownRenderer
            content={metadata.content}
            className="prose-sm sm:prose lg:prose-lg"
          />
        </CardContent>
      </Card>

      {showComments && (
        <div className="mt-6 sm:mt-8">
          <CommentsSection
            root={event}
            title="Comments"
            emptyStateMessage="No comments yet"
            emptyStateSubtitle="Be the first to share your thoughts!"
          />
        </div>
      )}
    </article>
  );
}