import { formatDistanceToNow } from 'date-fns';
import type { NostrEvent } from '@nostrify/nostrify';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { CalendarIcon, MessageCircleIcon } from 'lucide-react';
import { useAuthor } from '@/hooks/useAuthor';
import { getBlogPostMetadata } from '@/hooks/useBlogPosts';
import { nip19 } from 'nostr-tools';
import { useNavigate } from 'react-router-dom';

interface BlogPostCardProps {
  event: NostrEvent;
}

export function BlogPostCard({ event }: BlogPostCardProps) {
  const navigate = useNavigate();
  const author = useAuthor(event.pubkey);
  const metadata = getBlogPostMetadata(event);

  const authorMetadata = author.data?.metadata;
  const displayName = authorMetadata?.display_name || authorMetadata?.name || 'Anonymous';
  const profileImage = authorMetadata?.picture;

  const publishedDate = new Date(metadata.publishedAt * 1000);

  // Create naddr for the blog post
  const naddr = nip19.naddrEncode({
    identifier: metadata.identifier,
    pubkey: event.pubkey,
    kind: event.kind,
  });

  // Truncate content for preview
  const contentPreview = metadata.content.length > 200
    ? metadata.content.substring(0, 200) + '...'
    : metadata.content;

  const handleClick = () => {
    navigate(`/${naddr}`);
  };

  return (
    <Card
      className="group cursor-pointer transition-all duration-200 hover:shadow-lg hover:scale-[1.01] sm:hover:scale-[1.02] border-0 shadow-md overflow-hidden"
      onClick={handleClick}
    >
      {metadata.image && (
        <div className="aspect-video w-full overflow-hidden">
          <img
            src={metadata.image}
            alt={metadata.title}
            className="h-full w-full object-cover transition-transform duration-200 group-hover:scale-105"
            loading="lazy"
          />
        </div>
      )}

      <CardHeader className="space-y-3 p-4 sm:p-6">
        <div className="flex items-start space-x-3">
          <Avatar className="h-8 w-8 sm:h-10 sm:w-10 flex-shrink-0">
            <AvatarImage src={profileImage} alt={displayName} />
            <AvatarFallback className="bg-primary text-primary-foreground text-xs">
              {displayName.charAt(0).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0 space-y-1">
            <p className="text-sm font-medium leading-none truncate">{displayName}</p>
            <div className="flex items-center space-x-1 text-xs text-muted-foreground">
              <CalendarIcon className="h-3 w-3 flex-shrink-0" />
              <span className="truncate">{formatDistanceToNow(publishedDate, { addSuffix: true })}</span>
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <h2 className="text-lg sm:text-xl font-bold leading-tight tracking-tight group-hover:text-primary transition-colors line-clamp-2">
            {metadata.title}
          </h2>

          {metadata.summary && (
            <p className="text-sm text-muted-foreground leading-relaxed line-clamp-2">
              {metadata.summary}
            </p>
          )}
        </div>

        {metadata.topics.length > 0 && (
          <div className="flex flex-wrap gap-1">
            {metadata.topics.slice(0, 3).map((topic) => (
              <Badge key={topic} variant="secondary" className="text-xs truncate max-w-20">
                #{topic}
              </Badge>
            ))}
            {metadata.topics.length > 3 && (
              <Badge variant="secondary" className="text-xs">
                +{metadata.topics.length - 3}
              </Badge>
            )}
          </div>
        )}
      </CardHeader>

      <CardContent className="pt-0 p-4 sm:p-6">
        <p className="text-sm text-muted-foreground leading-relaxed line-clamp-3 mb-4">
          {contentPreview.replace(/[#*`[\]]/g, '')} {/* Remove markdown formatting for preview */}
        </p>

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-1 text-xs text-muted-foreground">
            <MessageCircleIcon className="h-3 w-3 flex-shrink-0" />
            <span>Comments</span>
          </div>
          <span className="text-xs text-primary font-medium">Read more →</span>
        </div>
      </CardContent>
    </Card>
  );
}