import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import rehypeHighlight from 'rehype-highlight';
import rehypeRaw from 'rehype-raw';
import { cn } from '@/lib/utils';

interface MarkdownRendererProps {
  content: string;
  className?: string;
}

export function MarkdownRenderer({ content, className }: MarkdownRendererProps) {
  return (
    <div className={cn("prose max-w-none", className)}>
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        rehypePlugins={[rehypeHighlight, rehypeRaw]}
        components={{
          // Custom components for better mobile styling
          h1: ({ children, ...props }) => (
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight mb-4 sm:mb-6 mt-6 sm:mt-8 first:mt-0" {...props}>
              {children}
            </h1>
          ),
          h2: ({ children, ...props }) => (
            <h2 className="text-xl sm:text-2xl font-semibold tracking-tight mb-3 sm:mb-4 mt-6 sm:mt-8 first:mt-0" {...props}>
              {children}
            </h2>
          ),
          h3: ({ children, ...props }) => (
            <h3 className="text-lg sm:text-xl font-semibold tracking-tight mb-2 sm:mb-3 mt-4 sm:mt-6 first:mt-0" {...props}>
              {children}
            </h3>
          ),
          h4: ({ children, ...props }) => (
            <h4 className="text-base sm:text-lg font-semibold tracking-tight mb-2 mt-3 sm:mt-4 first:mt-0" {...props}>
              {children}
            </h4>
          ),
          p: ({ children, ...props }) => (
            <p className="leading-6 sm:leading-7 mb-3 sm:mb-4 last:mb-0 text-sm sm:text-base" {...props}>
              {children}
            </p>
          ),
          a: ({ children, href, ...props }) => (
            <a
              href={href}
              className="text-primary underline underline-offset-4 hover:text-primary/80 transition-colors"
              target={href?.startsWith('http') ? '_blank' : undefined}
              rel={href?.startsWith('http') ? 'noopener noreferrer' : undefined}
              {...props}
            >
              {children}
            </a>
          ),
          blockquote: ({ children, ...props }) => (
            <blockquote className="border-l-4 border-primary/20 pl-3 sm:pl-4 italic text-muted-foreground my-4 sm:my-6 text-sm sm:text-base" {...props}>
              {children}
            </blockquote>
          ),
          ul: ({ children, ...props }) => (
            <ul className="list-disc list-inside space-y-1 sm:space-y-2 mb-3 sm:mb-4 text-sm sm:text-base" {...props}>
              {children}
            </ul>
          ),
          ol: ({ children, ...props }) => (
            <ol className="list-decimal list-inside space-y-1 sm:space-y-2 mb-3 sm:mb-4 text-sm sm:text-base" {...props}>
              {children}
            </ol>
          ),
          li: ({ children, ...props }) => (
            <li className="leading-6 sm:leading-7" {...props}>
              {children}
            </li>
          ),
          code: ({ children, className, ...props }) => {
            const isInline = !className;
            if (isInline) {
              return (
                <code className="bg-muted px-1 sm:px-1.5 py-0.5 rounded text-xs sm:text-sm font-mono" {...props}>
                  {children}
                </code>
              );
            }
            return (
              <code className={className} {...props}>
                {children}
              </code>
            );
          },
          pre: ({ children, ...props }) => (
            <pre className="bg-muted p-3 sm:p-4 rounded-lg overflow-x-auto mb-3 sm:mb-4 text-xs sm:text-sm" {...props}>
              {children}
            </pre>
          ),
          img: ({ src, alt, ...props }) => (
            <img
              src={src}
              alt={alt}
              className="rounded-lg max-w-full h-auto my-4 sm:my-6 mx-auto"
              loading="lazy"
              {...props}
            />
          ),
          table: ({ children, ...props }) => (
            <div className="overflow-x-auto my-4 sm:my-6 -mx-4 sm:mx-0">
              <table className="w-full border-collapse border border-border min-w-full" {...props}>
                {children}
              </table>
            </div>
          ),
          th: ({ children, ...props }) => (
            <th className="border border-border bg-muted px-2 sm:px-4 py-1 sm:py-2 text-left font-semibold text-xs sm:text-sm" {...props}>
              {children}
            </th>
          ),
          td: ({ children, ...props }) => (
            <td className="border border-border px-2 sm:px-4 py-1 sm:py-2 text-xs sm:text-sm" {...props}>
              {children}
            </td>
          ),
          hr: ({ ...props }) => (
            <hr className="border-border my-6 sm:my-8" {...props} />
          ),
        }}
      >
        {content}
      </ReactMarkdown>
    </div>
  );
}