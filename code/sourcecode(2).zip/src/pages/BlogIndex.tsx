import { useBlogPosts } from '@/hooks/useBlogPosts';
import { BlogPostCard } from '@/components/BlogPostCard';
import { Skeleton } from '@/components/ui/skeleton';
import { Card, CardContent } from '@/components/ui/card';
import { RelaySelector } from '@/components/RelaySelector';
import { ZapIcon } from 'lucide-react';

export function BlogIndex() {
  const { data: posts, isLoading, error } = useBlogPosts();

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 sm:py-6">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center space-x-2 sm:space-x-3 min-w-0">
              <div className="flex items-center justify-center w-8 h-8 sm:w-10 sm:h-10 bg-primary rounded-lg flex-shrink-0">
                <ZapIcon className="h-4 w-4 sm:h-6 sm:w-6 text-primary-foreground" />
              </div>
              <div className="min-w-0">
                <h1 className="text-lg sm:text-2xl font-bold tracking-tight truncate">Zap This Blog</h1>
                <p className="text-xs sm:text-sm text-muted-foreground hidden sm:block">Decentralized blogging on Nostr</p>
              </div>
            </div>
            <div className="flex-shrink-0">
              <RelaySelector className="w-32 sm:w-auto" />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6 sm:py-8">
        {isLoading && (
          <div className="grid gap-4 sm:gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {Array.from({ length: 6 }).map((_, i) => (
              <Card key={i} className="border-0 shadow-md overflow-hidden">
                <div className="aspect-video w-full">
                  <Skeleton className="h-full w-full" />
                </div>
                <div className="p-4 sm:p-6 space-y-4">
                  <div className="flex items-center space-x-3">
                    <Skeleton className="h-8 w-8 rounded-full flex-shrink-0" />
                    <div className="space-y-1 min-w-0 flex-1">
                      <Skeleton className="h-4 w-24" />
                      <Skeleton className="h-3 w-16" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Skeleton className="h-5 sm:h-6 w-full" />
                    <Skeleton className="h-4 w-4/5" />
                    <Skeleton className="h-4 w-3/5" />
                  </div>
                  <div className="flex gap-2">
                    <Skeleton className="h-5 w-16" />
                    <Skeleton className="h-5 w-20" />
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}

        {error && (
          <Card className="border-dashed border-destructive/50">
            <CardContent className="py-8 sm:py-12 px-4 sm:px-8 text-center">
              <div className="max-w-sm mx-auto space-y-4 sm:space-y-6">
                <p className="text-destructive text-sm sm:text-base">
                  Failed to load blog posts. Try another relay?
                </p>
                <RelaySelector className="w-full" />
              </div>
            </CardContent>
          </Card>
        )}

        {!isLoading && !error && posts && posts.length === 0 && (
          <Card className="border-dashed">
            <CardContent className="py-8 sm:py-12 px-4 sm:px-8 text-center">
              <div className="max-w-sm mx-auto space-y-4 sm:space-y-6">
                <div className="space-y-2">
                  <ZapIcon className="h-10 w-10 sm:h-12 sm:w-12 text-muted-foreground mx-auto" />
                  <h3 className="text-base sm:text-lg font-semibold">No blog posts found</h3>
                  <p className="text-muted-foreground text-sm sm:text-base">
                    No posts available on this relay. Try switching to another relay to discover content.
                  </p>
                </div>
                <RelaySelector className="w-full" />
              </div>
            </CardContent>
          </Card>
        )}

        {!isLoading && !error && posts && posts.length > 0 && (
          <div className="space-y-6 sm:space-y-8">
            <div className="text-center space-y-2">
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight">Latest Posts</h2>
              <p className="text-muted-foreground text-sm sm:text-base">
                Discover the latest thoughts and insights
              </p>
            </div>

            <div className="grid gap-4 sm:gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {posts.map((post) => (
                <BlogPostCard
                  key={`${post.pubkey}:${post.kind}:${post.tags.find(([name]) => name === 'd')?.[1]}`}
                  event={post}
                />
              ))}
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t bg-card/50 backdrop-blur-sm mt-12 sm:mt-16">
        <div className="container mx-auto px-4 py-6 sm:py-8">
          <div className="flex flex-col sm:flex-row items-center justify-between space-y-3 sm:space-y-0 text-center sm:text-left">
            <div className="flex items-center space-x-2 text-xs sm:text-sm text-muted-foreground">
              <ZapIcon className="h-4 w-4 flex-shrink-0" />
              <span>Powered by Nostr Protocol</span>
            </div>
            <div className="text-xs sm:text-sm text-muted-foreground">
              Vibed with{' '}
              <a
                href="https://soapbox.pub/mkstack"
                target="_blank"
                rel="noopener noreferrer"
                className="text-primary hover:underline"
              >
                MKStack
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}