import { nip19 } from 'nostr-tools';
import { useParams } from 'react-router-dom';
import { useNostr } from '@nostrify/react';
import { useQuery } from '@tanstack/react-query';
import { BlogPost } from '@/components/BlogPost';
import { Button } from '@/components/ui/button';
import { ArrowLeftIcon } from 'lucide-react';
import { Link } from 'react-router-dom';
import NotFound from './NotFound';

export function NIP19Page() {
  const { nip19: identifier } = useParams<{ nip19: string }>();
  const { nostr } = useNostr();

  // Always call hooks first, before any early returns
  const { data: event, isLoading } = useQuery({
    queryKey: ['nip19-event', identifier],
    queryFn: async (c) => {
      if (!identifier) return null;

      let decoded;
      try {
        decoded = nip19.decode(identifier);
      } catch {
        return null;
      }

      const { type, data } = decoded;
      const signal = AbortSignal.any([c.signal, AbortSignal.timeout(5000)]);

      if (type === 'naddr') {
        const naddr = data as nip19.AddressPointer;
        const events = await nostr.query([{
          kinds: [naddr.kind],
          authors: [naddr.pubkey],
          '#d': [naddr.identifier],
          limit: 1,
        }], { signal });
        return events[0] || null;
      }

      if (type === 'nevent') {
        const nevent = data as nip19.EventPointer;
        const events = await nostr.query([{
          ids: [nevent.id],
          limit: 1,
        }], { signal });
        return events[0] || null;
      }

      return null;
    },
    enabled: !!identifier,
  });

  if (!identifier) {
    return <NotFound />;
  }

  let decoded;
  try {
    decoded = nip19.decode(identifier);
  } catch {
    return <NotFound />;
  }

  const { type } = decoded;

  switch (type) {
    case 'npub':
    case 'nprofile':
      // Profile view placeholder
      return <div>Profile placeholder</div>;

    case 'note':
      // Note view placeholder
      return <div>Note placeholder</div>;

    case 'nevent':
    case 'naddr':
      if (isLoading) {
        return (
          <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20">
            <div className="container mx-auto px-4 py-6 sm:py-8 max-w-4xl">
              <div className="animate-pulse space-y-4 sm:space-y-6">
                <div className="h-6 sm:h-8 bg-muted rounded w-24 sm:w-32"></div>
                <div className="h-48 sm:h-64 bg-muted rounded"></div>
                <div className="space-y-3 sm:space-y-4">
                  <div className="h-5 sm:h-6 bg-muted rounded w-3/4"></div>
                  <div className="h-4 bg-muted rounded w-1/2"></div>
                  <div className="h-24 sm:h-32 bg-muted rounded"></div>
                </div>
              </div>
            </div>
          </div>
        );
      }

      if (!event) {
        return <NotFound />;
      }

      // Check if it's a blog post (kind 30023)
      if (event.kind === 30023) {
        return (
          <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20">
            <div className="container mx-auto px-4 py-6 sm:py-8 max-w-4xl">
              <div className="mb-4 sm:mb-6">
                <Button variant="ghost" asChild className="mb-4 hover:bg-primary/10 text-sm sm:text-base">
                  <Link to="/">
                    <ArrowLeftIcon className="h-4 w-4 mr-2 flex-shrink-0" />
                    <span className="truncate">Back to all posts</span>
                  </Link>
                </Button>
              </div>

              <BlogPost event={event} showComments={true} />
            </div>
          </div>
        );
      }

      // For other event types, show a generic placeholder
      return <div>Event view placeholder</div>;

    default:
      return <NotFound />;
  }
}