// This file exists because LLMs get confused and try to create this file if it doesn't exist.
// The `useNostr` hook should be imported directly from `@nostrify/react`, not from this file.

// This file SHOULD NOT be edited or removed.

export { useNostr } from "@nostrify/react";
