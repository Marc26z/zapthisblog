import { useNostr } from '@nostrify/react';
import { useQuery } from '@tanstack/react-query';
import type { NostrEvent } from '@nostrify/nostrify';
import { nip19 } from 'nostr-tools';

// Decode the npub to get the pubkey
const BLOG_AUTHOR_NPUB = 'npub1marc26z8nh3xkj5rcx7ufkatvx6ueqhp5vfw9v5teq26z254renshtf3g0';
const BLOG_AUTHOR_PUBKEY = nip19.decode(BLOG_AUTHOR_NPUB).data as string;

// Validator function for NIP-23 blog posts
function validateBlogPost(event: NostrEvent): boolean {
  // Check if it's a blog post kind
  if (event.kind !== 30023) return false;

  // Check for required 'd' tag (identifier)
  const d = event.tags.find(([name]) => name === 'd')?.[1];
  if (!d) return false;

  // Content should be markdown text
  if (typeof event.content !== 'string') return false;

  return true;
}

export function useBlogPosts() {
  const { nostr } = useNostr();

  return useQuery({
    queryKey: ['blog-posts', BLOG_AUTHOR_PUBKEY],
    queryFn: async (c) => {
      const signal = AbortSignal.any([c.signal, AbortSignal.timeout(5000)]);
      
      const events = await nostr.query([{
        kinds: [30023],
        authors: [BLOG_AUTHOR_PUBKEY],
        limit: 50,
      }], { signal });

      // Filter and validate blog posts
      const validPosts = events.filter(validateBlogPost);

      // Sort by created_at descending (newest first)
      return validPosts.sort((a, b) => b.created_at - a.created_at);
    },
    staleTime: 1000 * 60 * 5, // 5 minutes
    gcTime: 1000 * 60 * 30, // 30 minutes
  });
}

// Helper function to extract blog post metadata
export function getBlogPostMetadata(event: NostrEvent) {
  const title = event.tags.find(([name]) => name === 'title')?.[1] || 'Untitled';
  const summary = event.tags.find(([name]) => name === 'summary')?.[1];
  const image = event.tags.find(([name]) => name === 'image')?.[1];
  const publishedAt = event.tags.find(([name]) => name === 'published_at')?.[1];
  const identifier = event.tags.find(([name]) => name === 'd')?.[1] || '';
  const topics = event.tags.filter(([name]) => name === 't').map(([, topic]) => topic);

  return {
    title,
    summary,
    image,
    publishedAt: publishedAt ? parseInt(publishedAt) : event.created_at,
    identifier,
    topics,
    content: event.content,
    createdAt: event.created_at,
  };
}